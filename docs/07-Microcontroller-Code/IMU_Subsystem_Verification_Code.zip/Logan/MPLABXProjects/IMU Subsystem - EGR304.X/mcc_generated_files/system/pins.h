/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define HAN_INPUT_TRIS                 TRISAbits.TRISA0
#define HAN_INPUT_LAT                  LATAbits.LATA0
#define HAN_INPUT_PORT                 PORTAbits.RA0
#define HAN_INPUT_WPU                  WPUAbits.WPUA0
#define HAN_INPUT_OD                   ODCONAbits.ODCA0
#define HAN_INPUT_ANS                  ANSELAbits.ANSELA0
#define HAN_INPUT_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define HAN_INPUT_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define HAN_INPUT_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define HAN_INPUT_GetValue()           PORTAbits.RA0
#define HAN_INPUT_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define HAN_INPUT_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define HAN_INPUT_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define HAN_INPUT_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define HAN_INPUT_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define HAN_INPUT_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define HAN_INPUT_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define HAN_INPUT_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RB1 aliases
#define IO_RB1_TRIS                 TRISBbits.TRISB1
#define IO_RB1_LAT                  LATBbits.LATB1
#define IO_RB1_PORT                 PORTBbits.RB1
#define IO_RB1_WPU                  WPUBbits.WPUB1
#define IO_RB1_OD                   ODCONBbits.ODCB1
#define IO_RB1_ANS                  ANSELBbits.ANSELB1
#define IO_RB1_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define IO_RB1_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define IO_RB1_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define IO_RB1_GetValue()           PORTBbits.RB1
#define IO_RB1_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define IO_RB1_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define IO_RB1_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define IO_RB1_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define IO_RB1_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define IO_RB1_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define IO_RB1_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define IO_RB1_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB2 aliases
#define IO_RB2_TRIS                 TRISBbits.TRISB2
#define IO_RB2_LAT                  LATBbits.LATB2
#define IO_RB2_PORT                 PORTBbits.RB2
#define IO_RB2_WPU                  WPUBbits.WPUB2
#define IO_RB2_OD                   ODCONBbits.ODCB2
#define IO_RB2_ANS                  ANSELBbits.ANSELB2
#define IO_RB2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define IO_RB2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define IO_RB2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define IO_RB2_GetValue()           PORTBbits.RB2
#define IO_RB2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define IO_RB2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define IO_RB2_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define IO_RB2_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define IO_RB2_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define IO_RB2_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define IO_RB2_SetAnalogMode()      do { ANSELBbits.ANSELB2 = 1; } while(0)
#define IO_RB2_SetDigitalMode()     do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set RD0 aliases
#define DEBUG_LED_TRIS                 TRISDbits.TRISD0
#define DEBUG_LED_LAT                  LATDbits.LATD0
#define DEBUG_LED_PORT                 PORTDbits.RD0
#define DEBUG_LED_WPU                  WPUDbits.WPUD0
#define DEBUG_LED_OD                   ODCONDbits.ODCD0
#define DEBUG_LED_ANS                  ANSELDbits.ANSELD0
#define DEBUG_LED_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define DEBUG_LED_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define DEBUG_LED_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define DEBUG_LED_GetValue()           PORTDbits.RD0
#define DEBUG_LED_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define DEBUG_LED_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define DEBUG_LED_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define DEBUG_LED_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define DEBUG_LED_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define DEBUG_LED_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define DEBUG_LED_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define DEBUG_LED_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define DEBUG_BUTTON_TRIS                 TRISDbits.TRISD1
#define DEBUG_BUTTON_LAT                  LATDbits.LATD1
#define DEBUG_BUTTON_PORT                 PORTDbits.RD1
#define DEBUG_BUTTON_WPU                  WPUDbits.WPUD1
#define DEBUG_BUTTON_OD                   ODCONDbits.ODCD1
#define DEBUG_BUTTON_ANS                  ANSELDbits.ANSELD1
#define DEBUG_BUTTON_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define DEBUG_BUTTON_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define DEBUG_BUTTON_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define DEBUG_BUTTON_GetValue()           PORTDbits.RD1
#define DEBUG_BUTTON_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define DEBUG_BUTTON_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define DEBUG_BUTTON_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define DEBUG_BUTTON_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define DEBUG_BUTTON_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define DEBUG_BUTTON_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define DEBUG_BUTTON_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define DEBUG_BUTTON_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define MAT_OUTPUT_TRIS                 TRISDbits.TRISD2
#define MAT_OUTPUT_LAT                  LATDbits.LATD2
#define MAT_OUTPUT_PORT                 PORTDbits.RD2
#define MAT_OUTPUT_WPU                  WPUDbits.WPUD2
#define MAT_OUTPUT_OD                   ODCONDbits.ODCD2
#define MAT_OUTPUT_ANS                  ANSELDbits.ANSELD2
#define MAT_OUTPUT_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define MAT_OUTPUT_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define MAT_OUTPUT_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define MAT_OUTPUT_GetValue()           PORTDbits.RD2
#define MAT_OUTPUT_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define MAT_OUTPUT_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define MAT_OUTPUT_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define MAT_OUTPUT_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define MAT_OUTPUT_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define MAT_OUTPUT_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define MAT_OUTPUT_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define MAT_OUTPUT_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RD3 aliases
#define IMU_INT1_TRIS                 TRISDbits.TRISD3
#define IMU_INT1_LAT                  LATDbits.LATD3
#define IMU_INT1_PORT                 PORTDbits.RD3
#define IMU_INT1_WPU                  WPUDbits.WPUD3
#define IMU_INT1_OD                   ODCONDbits.ODCD3
#define IMU_INT1_ANS                  ANSELDbits.ANSELD3
#define IMU_INT1_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define IMU_INT1_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define IMU_INT1_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define IMU_INT1_GetValue()           PORTDbits.RD3
#define IMU_INT1_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define IMU_INT1_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define IMU_INT1_SetPullup()          do { WPUDbits.WPUD3 = 1; } while(0)
#define IMU_INT1_ResetPullup()        do { WPUDbits.WPUD3 = 0; } while(0)
#define IMU_INT1_SetPushPull()        do { ODCONDbits.ODCD3 = 0; } while(0)
#define IMU_INT1_SetOpenDrain()       do { ODCONDbits.ODCD3 = 1; } while(0)
#define IMU_INT1_SetAnalogMode()      do { ANSELDbits.ANSELD3 = 1; } while(0)
#define IMU_INT1_SetDigitalMode()     do { ANSELDbits.ANSELD3 = 0; } while(0)

// get/set RD5 aliases
#define YAZ_OUTPUT_TRIS                 TRISDbits.TRISD5
#define YAZ_OUTPUT_LAT                  LATDbits.LATD5
#define YAZ_OUTPUT_PORT                 PORTDbits.RD5
#define YAZ_OUTPUT_WPU                  WPUDbits.WPUD5
#define YAZ_OUTPUT_OD                   ODCONDbits.ODCD5
#define YAZ_OUTPUT_ANS                  ANSELDbits.ANSELD5
#define YAZ_OUTPUT_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define YAZ_OUTPUT_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define YAZ_OUTPUT_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define YAZ_OUTPUT_GetValue()           PORTDbits.RD5
#define YAZ_OUTPUT_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define YAZ_OUTPUT_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define YAZ_OUTPUT_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define YAZ_OUTPUT_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define YAZ_OUTPUT_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define YAZ_OUTPUT_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define YAZ_OUTPUT_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define YAZ_OUTPUT_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RF1 aliases
#define TEAM_EXTRA_OUTPUT_TRIS                 TRISFbits.TRISF1
#define TEAM_EXTRA_OUTPUT_LAT                  LATFbits.LATF1
#define TEAM_EXTRA_OUTPUT_PORT                 PORTFbits.RF1
#define TEAM_EXTRA_OUTPUT_WPU                  WPUFbits.WPUF1
#define TEAM_EXTRA_OUTPUT_OD                   ODCONFbits.ODCF1
#define TEAM_EXTRA_OUTPUT_ANS                  ANSELFbits.ANSELF1
#define TEAM_EXTRA_OUTPUT_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define TEAM_EXTRA_OUTPUT_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define TEAM_EXTRA_OUTPUT_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define TEAM_EXTRA_OUTPUT_GetValue()           PORTFbits.RF1
#define TEAM_EXTRA_OUTPUT_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define TEAM_EXTRA_OUTPUT_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define TEAM_EXTRA_OUTPUT_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define TEAM_EXTRA_OUTPUT_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define TEAM_EXTRA_OUTPUT_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define TEAM_EXTRA_OUTPUT_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define TEAM_EXTRA_OUTPUT_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define TEAM_EXTRA_OUTPUT_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/