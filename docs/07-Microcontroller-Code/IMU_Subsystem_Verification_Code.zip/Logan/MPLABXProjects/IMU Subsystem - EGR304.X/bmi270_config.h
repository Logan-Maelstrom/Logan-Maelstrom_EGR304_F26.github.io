/* 
 * File:   bmi270_config.h
 * Author: Logan
 *
 * Created on November 23, 2026, 9:58 PM
 */

#ifndef BMI270_CONFIG_H
#define BMI270_CONFIG_H

#include <stdint.h>
#include <stddef.h>

/*
 * Bosch BMI270 configuration data.
 * The actual configuration array is stored in bmi270_config.c.
 */
extern const uint8_t bmi270_config_file[];
extern const size_t bmi270_config_file_size;

#endif /* BMI270_CONFIG_H */