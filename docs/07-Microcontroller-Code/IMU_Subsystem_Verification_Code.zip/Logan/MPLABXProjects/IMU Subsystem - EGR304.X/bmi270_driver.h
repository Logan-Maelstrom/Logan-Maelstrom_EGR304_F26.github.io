/*
 * File:   bmi270_driver.h
 * Author: Logan
 *
 * Created on November 22, 2026, 2:07 PM
 */


#ifndef BMI270_DRIVER_H
#define BMI270_DRIVER_H

#include <stdint.h>
#include <stdbool.h>

/*
 * BMI270 I2C configuration
 *
 * SDO is tied to GND on our PCB, selecting 7-bit address 0x68.
 */
#define BMI270_I2C_ADDRESS       0x68U

/*
 * Basic BMI270 registers
 */
#define BMI270_REG_CHIP_ID       0x00U

/*
 * Expected value contained in CHIP_ID register.
 */
#define BMI270_CHIP_ID_VALUE     0x24U

/*
 * BMI270 sensor data registers
 */
#define BMI270_REG_ACC_X_LSB     0x0CU
#define BMI270_REG_GYR_X_LSB     0x12U

/*
 * BMI270 initialization registers
 */
#define BMI270_REG_INTERNAL_STATUS   0x21U
#define BMI270_REG_INIT_CTRL         0x59U
#define BMI270_REG_INIT_ADDR_0       0x5BU
#define BMI270_REG_INIT_ADDR_1       0x5CU
#define BMI270_REG_INIT_DATA         0x5EU
#define BMI270_REG_PWR_CONF          0x7CU
#define BMI270_REG_PWR_CTRL          0x7DU

#define BMI270_INIT_OK               0x01U

/*
 * BMI270 accelerometer/gyroscope configuration registers
 */
#define BMI270_REG_ACC_CONF       0x40U
#define BMI270_REG_ACC_RANGE      0x41U
#define BMI270_REG_GYR_CONF       0x42U
#define BMI270_REG_GYR_RANGE      0x43U

/*
 * Initial accelerometer/gyroscope operating settings
 */
#define BMI270_ACC_CONF_100HZ       0xA8U
#define BMI270_ACC_RANGE_4G         0x01U

#define BMI270_GYR_CONF_200HZ       0xA9U
#define BMI270_GYR_RANGE_500DPS     0x02U

#define BMI270_PWR_CTRL_ACC_GYR     0x06U

/*
 * Raw 3-axis sensor sample
 */
typedef struct
{
    int16_t x;
    int16_t y;
    int16_t z;
} bmi270_axes_t;

/*
 * Driver status values.
 */
typedef enum
{
    BMI270_OK = 0,
    BMI270_ERROR_I2C,
    BMI270_ERROR_TIMEOUT,
    BMI270_ERROR_CHIP_ID
} bmi270_status_t;


/*
 * Reads one BMI270 register.
 */
bmi270_status_t BMI270_ReadRegister(uint8_t reg, uint8_t *value);


/*
 * Writes one BMI270 register.
 */
bmi270_status_t BMI270_WriteRegister(uint8_t reg, uint8_t value);


/*
 * Reads the BMI270 CHIP_ID register.
 */
bmi270_status_t BMI270_ReadChipID(uint8_t *chip_id);


/*
 * Checks whether the connected sensor reports the expected
 * BMI270 chip ID.
 */
bmi270_status_t BMI270_CheckConnection(void);



/*
 * Reads raw accelerometer X/Y/Z data.
 */
bmi270_status_t BMI270_ReadAccelRaw(bmi270_axes_t *accel);

/*
 * Reads raw gyroscope X/Y/Z data.
 */
bmi270_status_t BMI270_ReadGyroRaw(bmi270_axes_t *gyro);

/*
 * Performs the BMI270 power-on configuration sequence.
 */
bmi270_status_t BMI270_Initialize(void);

/*
 * Configures and enables the accelerometer and gyroscope.
 */
bmi270_status_t BMI270_ConfigureSensors(void);

#endif /* BMI270_DRIVER_H */