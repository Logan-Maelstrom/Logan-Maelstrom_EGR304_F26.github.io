/*
 * File:   bmi270_driver.c
 * Author: Logan
 *
 * Created on November 22, 2026, 2:11 PM
 */


#define _XTAL_FREQ 64000000UL

#include <xc.h>
#include <stddef.h>

#include "bmi270_driver.h"
#include "bmi270_config.h"
#include "mcc_generated_files/i2c_host/i2c1.h"

#define BMI270_I2C_TIMEOUT  100000UL


/*
 * Wait for the MCC I2C driver to finish the current transaction.
 */
static bmi270_status_t BMI270_WaitForI2C(void)
{
    uint32_t timeout = BMI270_I2C_TIMEOUT;

    while (I2C1_IsBusy())
    {
        if (--timeout == 0U)
        {
            return BMI270_ERROR_TIMEOUT;
        }
    }

    if (I2C1_ErrorGet() != I2C_ERROR_NONE)
    {
        return BMI270_ERROR_I2C;
    }

    return BMI270_OK;
}


bmi270_status_t BMI270_ReadRegister(uint8_t reg, uint8_t *value)
{
    if (value == NULL)
    {
        return BMI270_ERROR_I2C;
    }

    /*
     * Write the register address, issue a repeated START,
     * then read one byte from the BMI270.
     */
    if (!I2C1_WriteRead(
            BMI270_I2C_ADDRESS,
            &reg,
            1U,
            value,
            1U))
    {
        return BMI270_ERROR_I2C;
    }

    return BMI270_WaitForI2C();
}

static bmi270_status_t BMI270_ReadRegisters(
    uint8_t start_reg,
    uint8_t *data,
    size_t length)
{
    if ((data == NULL) || (length == 0U))
    {
        return BMI270_ERROR_I2C;
    }

    /*
     * Send the starting register address, issue a repeated START,
     * then read the requested consecutive bytes.
     */
    if (!I2C1_WriteRead(
            BMI270_I2C_ADDRESS,
            &start_reg,
            1U,
            data,
            length))
    {
        return BMI270_ERROR_I2C;
    }

    return BMI270_WaitForI2C();
}

bmi270_status_t BMI270_WriteRegister(uint8_t reg, uint8_t value)
{
    uint8_t data[2];

    data[0] = reg;
    data[1] = value;

    if (!I2C1_Write(
            BMI270_I2C_ADDRESS,
            data,
            2U))
    {
        return BMI270_ERROR_I2C;
    }

    return BMI270_WaitForI2C();
}

static bmi270_status_t BMI270_WriteRegisters(
    uint8_t start_reg,
    const uint8_t *data,
    size_t length)
{
    uint8_t buffer[33];
    size_t i;

    /*
     * Maximum payload is 32 bytes plus
     * one byte for the starting register address.
     */
    if ((data == NULL) || (length == 0U) || (length > 32U))
    {
        return BMI270_ERROR_I2C;
    }

    buffer[0] = start_reg;

    for (i = 0U; i < length; i++)
    {
        buffer[i + 1U] = data[i];
    }

    if (!I2C1_Write(
            BMI270_I2C_ADDRESS,
            buffer,
            length + 1U))
    {
        return BMI270_ERROR_I2C;
    }

    return BMI270_WaitForI2C();
}

static bmi270_status_t BMI270_UploadConfig(void)
{
    size_t index = 0U;

    while (index < bmi270_config_file_size)
    {
        uint16_t word_address;
        uint8_t addr0;
        uint8_t addr1;
        size_t remaining;
        size_t chunk_length;
        bmi270_status_t status;

        word_address = (uint16_t)(index / 2U);

        addr0 = (uint8_t)(word_address & 0x0FU);
        addr1 = (uint8_t)(word_address >> 4U);

        status = BMI270_WriteRegister(BMI270_REG_INIT_ADDR_0, addr0);
        if (status != BMI270_OK)
        {
            return status;
        }

        status = BMI270_WriteRegister(BMI270_REG_INIT_ADDR_1, addr1);
        if (status != BMI270_OK)
        {
            return status;
        }

        remaining = bmi270_config_file_size - index;

        if (remaining > 32U)
        {
            chunk_length = 32U;
        }
        else
        {
            chunk_length = remaining;
        }

        status = BMI270_WriteRegisters(
            BMI270_REG_INIT_DATA,
            &bmi270_config_file[index],
            chunk_length);

        if (status != BMI270_OK)
        {
            return status;
        }

        index += chunk_length;
    }

    return BMI270_OK;
}

bmi270_status_t BMI270_ReadChipID(uint8_t *chip_id)
{
    return BMI270_ReadRegister(BMI270_REG_CHIP_ID, chip_id);
}


bmi270_status_t BMI270_CheckConnection(void)
{
    uint8_t chip_id = 0U;
    bmi270_status_t status;

    status = BMI270_ReadChipID(&chip_id);

    if (status != BMI270_OK)
    {
        return status;
    }

    if (chip_id != BMI270_CHIP_ID_VALUE)
    {
        return BMI270_ERROR_CHIP_ID;
    }

    return BMI270_OK;
}


bmi270_status_t BMI270_ReadAccelRaw(bmi270_axes_t *accel)
{
    uint8_t data[6];
    bmi270_status_t status;

    if (accel == NULL)
    {
        return BMI270_ERROR_I2C;
    }

    status = BMI270_ReadRegisters(
        BMI270_REG_ACC_X_LSB,
        data,
        sizeof(data));

    if (status != BMI270_OK)
    {
        return status;
    }

    accel->x = (int16_t)(((uint16_t)data[1] << 8) | data[0]);
    accel->y = (int16_t)(((uint16_t)data[3] << 8) | data[2]);
    accel->z = (int16_t)(((uint16_t)data[5] << 8) | data[4]);

    return BMI270_OK;
}


bmi270_status_t BMI270_ReadGyroRaw(bmi270_axes_t *gyro)
{
    uint8_t data[6];
    bmi270_status_t status;

    if (gyro == NULL)
    {
        return BMI270_ERROR_I2C;
    }

    status = BMI270_ReadRegisters(
        BMI270_REG_GYR_X_LSB,
        data,
        sizeof(data));

    if (status != BMI270_OK)
    {
        return status;
    }

    gyro->x = (int16_t)(((uint16_t)data[1] << 8) | data[0]);
    gyro->y = (int16_t)(((uint16_t)data[3] << 8) | data[2]);
    gyro->z = (int16_t)(((uint16_t)data[5] << 8) | data[4]);

    return BMI270_OK;
}

bmi270_status_t BMI270_Initialize(void)
{
    bmi270_status_t status;
    uint8_t internal_status = 0U;
    uint8_t attempts = 0U;

    /*
     * Verify that the BMI270 is responding before attempting
     * the configuration upload.
     */
    status = BMI270_CheckConnection();

    if (status != BMI270_OK)
    {
        return status;
    }

    /*
     * Disable advanced power save before loading the
     * BMI270 configuration file.
     */
    status = BMI270_WriteRegister(BMI270_REG_PWR_CONF, 0x00U);

    if (status != BMI270_OK)
    {
        return status;
    }

    /*
     * Bosch requires a delay after disabling advanced
     * power save before configuration loading begins.
     */
    __delay_ms(1);

    /*
     * Prepare the BMI270 for configuration loading.
     */
    status = BMI270_WriteRegister(BMI270_REG_INIT_CTRL, 0x00U);

    if (status != BMI270_OK)
    {
        return status;
    }

    /*
     * Upload the official Bosch BMI270 configuration file
     * in small chunks.
     */
    status = BMI270_UploadConfig();

    if (status != BMI270_OK)
    {
        return status;
    }

    /*
     * Tell the BMI270 that configuration loading is complete.
     */
    status = BMI270_WriteRegister(BMI270_REG_INIT_CTRL, 0x01U);

    if (status != BMI270_OK)
    {
        return status;
    }

    /*
     * Initialization may require several milliseconds.
     * Poll INTERNAL_STATUS rather than assuming completion.
     *
     * 50 attempts x 1 ms gives approximately a 50 ms timeout.
     */
    for (attempts = 0U; attempts < 50U; attempts++)
    {
        __delay_ms(1);

        status = BMI270_ReadRegister(
            BMI270_REG_INTERNAL_STATUS,
            &internal_status);

        if (status != BMI270_OK)
        {
            return status;
        }

        /*
         * Bits [3:0] contain the initialization message.
         * 0x01 indicates successful initialization.
         */
        if ((internal_status & 0x0FU) == BMI270_INIT_OK)
        {
            return BMI270_OK;
        }
    }

    return BMI270_ERROR_TIMEOUT;
}

bmi270_status_t BMI270_ConfigureSensors(void)
{
    bmi270_status_t status;

    /*
     * Configure accelerometer:
     * 100 Hz output data rate
     * +/- 4 g measurement range
     */
    status = BMI270_WriteRegister(
        BMI270_REG_ACC_CONF,
        BMI270_ACC_CONF_100HZ);

    if (status != BMI270_OK)
    {
        return status;
    }

    status = BMI270_WriteRegister(
        BMI270_REG_ACC_RANGE,
        BMI270_ACC_RANGE_4G);

    if (status != BMI270_OK)
    {
        return status;
    }

    /*
     * Configure gyroscope:
     * 200 Hz output data rate
     * +/- 500 degrees/second measurement range
     */
    status = BMI270_WriteRegister(
        BMI270_REG_GYR_CONF,
        BMI270_GYR_CONF_200HZ);

    if (status != BMI270_OK)
    {
        return status;
    }

    status = BMI270_WriteRegister(
        BMI270_REG_GYR_RANGE,
        BMI270_GYR_RANGE_500DPS);

    if (status != BMI270_OK)
    {
        return status;
    }

    /*
     * Enable accelerometer and gyroscope.
     */
    status = BMI270_WriteRegister(
        BMI270_REG_PWR_CTRL,
        BMI270_PWR_CTRL_ACC_GYR);

    if (status != BMI270_OK)
    {
        return status;
    }

    __delay_ms(10);

    return BMI270_OK;
}