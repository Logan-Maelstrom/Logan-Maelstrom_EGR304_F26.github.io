 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
/*
 * ================================================================
 * EGR 304 - Drowsy Driver Alarm
 * IMU Subsystem - Complete Firmware
 * ================================================================
 *
 * INTENDED SYSTEM:
 *
 *   Hannah HIGH
 *       +
 *   BMI270 detects significant head/movement event
 *       |
 *       v
 *   Debug LED ON
 *   Matthew output HIGH
 *   Yazmin output HIGH
 *
 *
 * DEBUG / HARDWARE VERIFICATION MODE:
 *
 *   Hannah HIGH
 *       +
 *   SW1 pressed
 *       |
 *       v
 *   Debug LED ON
 *   Matthew output HIGH
 *   Yazmin output HIGH
 *
 *
 * IMPORTANT:
 *
 * SW1 simulates ONLY the IMU event.
 * SW1 does NOT bypass Hannah.
 *
 * If BMI270 initialization fails, the debug-button path
 * continues operating so the remainder of the subsystem
 * can still be verified.
 * ================================================================
 */

#include "mcc_generated_files/system/system.h"
#include "bmi270_driver.h"

#include <stdint.h>
#include <stdbool.h>


/*
 * ================================================================
 * MOTION-DETECTION SETTINGS
 * ================================================================
 *
 * These are initial calibration values.
 *
 * MOTION_DELTA_THRESHOLD:
 *   Required change between consecutive acceleration samples.
 *
 * MOTION_RELEASE_THRESHOLD:
 *   Lower threshold used to release/reset the event.
 *
 * Using a change in acceleration is better for this subsystem
 * than simply checking absolute board tilt because the desired
 * behavior is closer to a sudden head movement / jerk.
 */

#define MOTION_DELTA_THRESHOLD       5000
#define MOTION_RELEASE_THRESHOLD     1500

/*
 * Number of consecutive quiet samples required before another
 * IMU event may be detected.
 */
#define QUIET_SAMPLES_REQUIRED       10


/*
 * ================================================================
 * HELPER FUNCTIONS
 * ================================================================
 */

/*
 * Absolute value for signed 16-bit acceleration differences.
 *
 * Use int32_t internally so -32768 can be handled safely.
 */
static int32_t abs32(int32_t value)
{
    if (value < 0)
    {
        return -value;
    }

    return value;
}


/*
 * Set all teammate/alarm outputs LOW.
 */
static void AlarmOutputsOff(void)
{
    DEBUG_LED_SetLow();

    MAT_OUTPUT_SetLow();

    /*
     * Old Yazmin/team-header output is no longer being used
     * for the final team connection.
     */
    YAZ_OUTPUT_SetLow();

    /*
     * Yazmin's actual final connection:
     * RF1 -> redundancy header pin 4.
     */
    TEAM_EXTRA_OUTPUT_SetLow();
}


/*
 * Set the physical alarm outputs HIGH.
 */
static void AlarmOutputsOn(void)
{
    DEBUG_LED_SetHigh();

    /*
     * Matthew:
     * RD2 -> Team Header.
     */
    MAT_OUTPUT_SetHigh();

    /*
     * Keep old Yazmin output inactive because Yazmin is using
     * RF1 / redundancy-header pin 4 in the final wiring.
     */
    YAZ_OUTPUT_SetLow();

    /*
     * Yazmin:
     * RF1 -> EXP_GPIO1 -> Redundancy Header pin 4.
     */
    TEAM_EXTRA_OUTPUT_SetHigh();
}


/*
 * ================================================================
 * MAIN APPLICATION
 * ================================================================
 */

int main(void)
{
    bmi270_status_t status;

    bmi270_axes_t accel;
    bmi270_axes_t previous_accel;

    bool imu_ready = false;
    bool have_previous_sample = false;

    bool imu_event = false;
    bool debug_event = false;
    bool subsystem_event = false;

    uint8_t quiet_samples = 0;

    int32_t delta_x;
    int32_t delta_y;
    int32_t delta_z;


    /*
     * ------------------------------------------------------------
     * PIC / MCC INITIALIZATION
     * ------------------------------------------------------------
     */

    SYSTEM_Initialize();


    /*
     * Make absolutely sure everything begins inactive.
     */

    AlarmOutputsOff();


    /*
     * Initialize previous acceleration values.
     */

    previous_accel.x = 0;
    previous_accel.y = 0;
    previous_accel.z = 0;


    /*
     * ============================================================
     * BMI270 STARTUP
     * ============================================================
     *
     * STEP 1:
     * Read CHIP_ID register.
     *
     * Expected BMI270 CHIP_ID = 0x24.
     */

    status = BMI270_CheckConnection();


    /*
     * STEP 2:
     * Upload Bosch configuration / initialize device.
     */

    if (status == BMI270_OK)
    {
        status = BMI270_Initialize();
    }


    /*
     * STEP 3:
     * Configure accelerometer and gyroscope.
     */

    if (status == BMI270_OK)
    {
        status = BMI270_ConfigureSensors();
    }


    /*
     * If every startup step succeeded, enable real IMU operation.
     *
     * If any step failed, imu_ready remains false.
     *
     * IMPORTANT:
     * The firmware DOES NOT stop here if the IMU fails.
     * Hannah + SW1 debug verification remains functional.
     */

    if (status == BMI270_OK)
    {
        imu_ready = true;
    }


    /*
     * ============================================================
     * MAIN LOOP
     * ============================================================
     */

    while (1)
    {
        /*
         * --------------------------------------------------------
         * DEBUG BUTTON
         * --------------------------------------------------------
         *
         * SW1 is ACTIVE LOW.
         *
         * Released:
         *     DEBUG_BUTTON = HIGH
         *
         * Pressed:
         *     DEBUG_BUTTON = LOW
         *
         * SW1 substitutes for an IMU event during verification.
         */

        debug_event = (DEBUG_BUTTON_GetValue() == 0);


        /*
         * --------------------------------------------------------
         * REAL BMI270 PROCESSING
         * --------------------------------------------------------
         */

        if (imu_ready)
        {
            /*
             * Read current raw acceleration.
             */

            status = BMI270_ReadAccelRaw(&accel);


            if (status == BMI270_OK)
            {
                /*
                 * The first valid sample establishes the baseline.
                 */

                if (!have_previous_sample)
                {
                    previous_accel = accel;
                    have_previous_sample = true;

                    imu_event = false;
                    quiet_samples = 0;
                }
                else
                {
                    /*
                     * Calculate change in acceleration since the
                     * previous sample.
                     */

                    delta_x =
                        abs32((int32_t)accel.x -
                              (int32_t)previous_accel.x);

                    delta_y =
                        abs32((int32_t)accel.y -
                              (int32_t)previous_accel.y);

                    delta_z =
                        abs32((int32_t)accel.z -
                              (int32_t)previous_accel.z);


                    /*
                     * ------------------------------------------------
                     * MOVEMENT / JERK DETECTION
                     * ------------------------------------------------
                     *
                     * A large acceleration change on ANY axis is
                     * treated as a possible drowsy-head movement.
                     */

                    if ((delta_x >= MOTION_DELTA_THRESHOLD) ||
                        (delta_y >= MOTION_DELTA_THRESHOLD) ||
                        (delta_z >= MOTION_DELTA_THRESHOLD))
                    {
                        imu_event = true;
                        quiet_samples = 0;
                    }
                    else
                    {
                        /*
                         * Wait for the sensor to become relatively
                         * quiet before clearing the event.
                         *
                         * This prevents one event from rapidly
                         * flickering on/off.
                         */

                        if ((delta_x <= MOTION_RELEASE_THRESHOLD) &&
                            (delta_y <= MOTION_RELEASE_THRESHOLD) &&
                            (delta_z <= MOTION_RELEASE_THRESHOLD))
                        {
                            if (quiet_samples <
                                QUIET_SAMPLES_REQUIRED)
                            {
                                quiet_samples++;
                            }
                        }
                        else
                        {
                            quiet_samples = 0;
                        }


                        /*
                         * Once enough quiet samples have occurred,
                         * reset the IMU event.
                         */

                        if (quiet_samples >=
                            QUIET_SAMPLES_REQUIRED)
                        {
                            imu_event = false;
                        }
                    }


                    /*
                     * Save this sample for comparison with the
                     * next sample.
                     */

                    previous_accel = accel;
                }
            }
            else
            {
                /*
                 * A runtime I2C read failed.
                 *
                 * Do not generate a false alarm.
                 */

                imu_event = false;
                have_previous_sample = false;
            }
        }
        else
        {
            /*
             * BMI270 startup failed.
             *
             * Real sensor detection remains disabled, but the
             * SW1 verification path continues functioning.
             */

            imu_event = false;
        }


        /*
         * --------------------------------------------------------
         * COMBINE REAL AND DEBUG EVENTS
         * --------------------------------------------------------
         *
         * Either:
         *
         *   real BMI270 movement
         *
         * OR
         *
         *   SW1 simulated movement
         *
         * counts as a subsystem event.
         */

        subsystem_event = (imu_event || debug_event);


        /*
         * ========================================================
         * FINAL TEAM LOGIC
         * ========================================================
         *
         * Hannah MUST send HIGH.
         *
         * Then an event must occur.
         *
         * Therefore:
         *
         * Hannah LOW + no event
         *      -> outputs LOW
         *
         * Hannah LOW + SW1
         *      -> outputs LOW
         *
         * Hannah HIGH + no event
         *      -> outputs LOW
         *
         * Hannah HIGH + SW1
         *      -> outputs HIGH
         *
         * Hannah HIGH + BMI270 movement
         *      -> outputs HIGH
         */

        if ((HAN_INPUT_GetValue() == 1) &&
            subsystem_event)
        {
            AlarmOutputsOn();
        }
        else
        {
            AlarmOutputsOff();
        }
    }


    /*
     * Program should never reach this point.
     */

    return 0;
}